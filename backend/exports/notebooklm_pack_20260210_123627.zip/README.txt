Pack NotebookLM - French Exercise App

Contenido:
- exercise_21: Biblioteca - Fill Blank