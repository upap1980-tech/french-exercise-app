Pack NotebookLM - French Exercise App

Contenido:
- exercise_80: Biblioteca - Fill Blank