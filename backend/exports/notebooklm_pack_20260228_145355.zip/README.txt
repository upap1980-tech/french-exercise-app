Pack NotebookLM - French Exercise App

Contenido:
- exercise_78: Biblioteca - Fill Blank