Pack NotebookLM - French Exercise App

Contenido:
- exercise_81: Biblioteca - Fill Blank