Pack NotebookLM - French Exercise App

Contenido:
- exercise_27: Partes de la casa  - Color Match