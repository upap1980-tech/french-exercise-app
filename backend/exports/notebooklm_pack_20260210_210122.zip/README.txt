Pack NotebookLM - French Exercise App

Contenido:
- exercise_32: Biblioteca - Fill Blank