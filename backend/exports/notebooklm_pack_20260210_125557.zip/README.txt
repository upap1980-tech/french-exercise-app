Pack NotebookLM - French Exercise App

Contenido:
- exercise_22: Biblioteca - Fill Blank