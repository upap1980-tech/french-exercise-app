Pack NotebookLM - French Exercise App

Contenido:
- exercise_28: Biblioteca - Fill Blank