Pack NotebookLM - French Exercise App

Contenido:
- exercise_77: Biblioteca - Fill Blank