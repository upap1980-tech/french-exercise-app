Pack NotebookLM - French Exercise App

Contenido:
- exercise_29: Biblioteca - Fill Blank