Pack NotebookLM - French Exercise App

Contenido:
- exercise_82: Biblioteca - Fill Blank