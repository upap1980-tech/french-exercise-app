Pack NotebookLM - French Exercise App

Contenido:
- exercise_33: Biblioteca - Fill Blank