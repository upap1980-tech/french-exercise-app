Pack NotebookLM - French Exercise App

Contenido:
- exercise_23: Biblioteca - Fill Blank